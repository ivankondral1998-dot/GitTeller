# Выполненные проверки, текущая среда

- Запуск: `sh tests-local/run.sh`.
- Вывод: `PASS: 15 model checks (test doubles for org.json; no Android runtime)`.
- Синтаксический разбор: `PARSE OK: 9 Java compilation units (syntax only, not Android compilation)`.
- Тесты используют небольшие заглушки `org.json` только для класса `Summary` и `CommitExplainer`. Это **не** настоящий Android/JUnit.
- Регрессионно проверены: неполная предыдущая выборка не порождает `added`; импорт не объявляется живой проверкой; сетевой снимок после импорта не сравнивается с неподтверждённой базой; неполный первый снимок обозначен.
- Пакет собран как ZIP с исходниками и тестами, но НЕ как APK.
- Изоляция: репозиторий GitHub не изменён, GitHub Actions не запускались.
