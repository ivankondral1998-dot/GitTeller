# GitTeller 1.0.3-audit — исходники после независимого аудита

Продолжение Android-кода Grok 1.0.2, не новый проект. Версия 1.0.3-audit существует **только как исходники**. APK 1.0.3-audit **не собран**. APK 1.0.2 остаётся исходным артефактом Grok, его SHA указан в `AUDIT_VERIFIED.md`.

## Сборка на компьютере с Android SDK

Требования из 1.0.2: JDK 17+, Gradle 8.9, Android SDK 35, build-tools 35.0.0, AGP 8.7.3.

```bash
gradle --no-daemon :app:testDebugUnitTest
gradle --no-daemon :app:assembleDebug
```

Сначала проверить тесты и затем собрать APK. Сохранить полные логи, SHA-256 и результат реальной установки на Android. В случае ошибки нельзя писать PASS.

Локальная частичная проверка без Android SDK:

```bash
sh tests-local/run.sh
```

Читайте `AUDIT_VERIFIED.md` и `TESTS_EXECUTED.md`. Полный оригинальный пакет сохранён отдельно у владельца.
