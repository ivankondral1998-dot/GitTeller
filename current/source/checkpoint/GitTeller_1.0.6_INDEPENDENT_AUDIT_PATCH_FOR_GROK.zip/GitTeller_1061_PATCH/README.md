GitTeller 1.0.6.1 — independent source-only audit patch.

Read AUDIT_FINDINGS_106.md, GROK_NEXT_TASK_107.md.

To run local model checks: sh tests-local/run.sh
APK in evidence/ is original Grok 1.0.6, NOT PATCHED.
