package app.unocontrol;

import java.net.URI;

/** Links are shown only for the selected repository, never arbitrary imported URLs. */
final class GithubLinks {
    private GithubLinks() {}

    static String recordUrl(String repo, String type, int number) {
        if (!validRepo(repo) || number <= 0) return null;
        if (!"issues".equals(type) && !"pull".equals(type)) return null;
        return "https://github.com/" + repo + "/" + type + "/" + number;
    }

    static String validatedRepoUrl(String repo, String candidate) {
        if (!validRepo(repo) || candidate == null) return null;
        try {
            URI u = new URI(candidate);
            if (!"https".equalsIgnoreCase(u.getScheme()) || !"github.com".equalsIgnoreCase(u.getHost())
                    || u.getUserInfo() != null || u.getPort() != -1 || u.getRawQuery() != null
                    || u.getRawFragment() != null) return null;
            String prefix = "/" + repo + "/";
            String path = u.getRawPath();
            if (path == null || !path.startsWith(prefix)) return null;
            String tail = path.substring(prefix.length());
            if (tail.matches("(?:issues|pull)/[1-9][0-9]*")) return candidate;
            if (tail.startsWith("tree/")) {
                String branch = tail.substring("tree/".length());
                if (branch.isEmpty() || branch.startsWith("/") || branch.endsWith("/")
                        || branch.contains("//") || branch.contains("..")
                        || branch.indexOf(' ') >= 0 || branch.indexOf('\\') >= 0)
                    return null;
                return candidate;
            }
        } catch (Exception ignored) { /* Never open malformed or untrusted URLs. */ }
        return null;
    }

    private static boolean validRepo(String repo) {
        return repo != null && repo.matches("[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}")
                && !repo.contains("..");
    }
}
