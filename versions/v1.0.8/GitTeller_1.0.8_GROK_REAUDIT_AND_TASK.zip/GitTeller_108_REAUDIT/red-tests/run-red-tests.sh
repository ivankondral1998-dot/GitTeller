#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
SRC="$ROOT/gitteller"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" "$SRC"/tests-local/org/json/*.java \
 "$SRC"/app/src/main/java/app/unocontrol/Summary.java \
 "$SRC"/app/src/main/java/app/unocontrol/SnapshotCodec.java \
 "$ROOT/red-tests/GitTellerRedProbe.java"
java -cp "$TMP" app.unocontrol.GitTellerRedProbe
