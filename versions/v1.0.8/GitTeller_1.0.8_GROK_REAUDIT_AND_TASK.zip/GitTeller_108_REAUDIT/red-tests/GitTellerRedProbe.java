package app.unocontrol;
import org.json.*;

/** These tests express expected user-observable events; they are expected RED on 1.0.7 patch. */
public final class GitTellerRedProbe {
  private static final String SHA = "0123456789abcdef0123456789abcdef01234567";
  static JSONObject snapshot(JSONArray issues, JSONArray pulls) {
    return new JSONObject().put("repo", "demo/proj").put("branchesComplete", true)
        .put("issuesComplete", true).put("pullsComplete", true)
        .put("branches", new JSONArray().put(new JSONObject().put("name", "main").put("sha", SHA)))
        .put("issues", issues).put("pulls", pulls);
  }
  static JSONObject issue(int n, String title, String state) {
    return new JSONObject().put("number", n).put("title", title).put("state", state);
  }
  static JSONObject pull(int n, String state, boolean merged) {
    return new JSONObject().put("number", n).put("title", "proposal").put("state", state).put("merged", merged);
  }
  static void check(String label, boolean observed, String detail) {
    System.out.println((observed ? "PASS" : "RED") + " | " + label + " | " + detail);
    if(!observed) failures++;
  }
  static int failures=0;
  public static void main(String[] args) throws Exception {
    JSONObject base = snapshot(new JSONArray(), new JSONArray());
    JSONObject createdIssue = snapshot(new JSONArray().put(issue(7,"Fix crash","open")), new JSONArray());
    Summary newIssue = Summary.of(createdIssue, base);
    check("new issue is a change", newIssue.issueChanges > 0, "observed issueChanges=" + newIssue.issueChanges);
    JSONObject priorPull = snapshot(new JSONArray(), new JSONArray().put(pull(5,"closed",false)));
    JSONObject mergedPull = snapshot(new JSONArray(), new JSONArray().put(pull(5,"closed",true)));
    Summary merge = Summary.of(mergedPull, priorPull);
    check("PR merge is a change despite closed->closed", merge.pullChanges > 0, "observed pullChanges=" + merge.pullChanges);
    JSONObject renamed = snapshot(new JSONArray().put(issue(7,"New title","open")), new JSONArray());
    Summary edit = Summary.of(renamed, createdIssue);
    check("issue title change is a change", edit.issueChanges > 0, "observed issueChanges=" + edit.issueChanges);
    JSONObject cleaned = SnapshotCodec.sanitizeSnapshot(mergedPull,"demo/proj");
    boolean keepMerged = cleaned.optJSONArray("pulls").optJSONObject(0).optBoolean("merged",false);
    check("backup preserves merged state", keepMerged, "observed merged=" + keepMerged);
    System.out.println("Known defects reproduced: " + failures + "/4 (expected 4 RED on 1.0.7 patch)");
    if (failures != 0) System.exit(2);
  }
}
