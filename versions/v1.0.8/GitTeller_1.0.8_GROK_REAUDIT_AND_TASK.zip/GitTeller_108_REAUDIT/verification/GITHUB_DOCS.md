Provider docs: https://docs.github.com/en/rest/commits/commits#compare-two-commits
GitHub PAT limitations: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
