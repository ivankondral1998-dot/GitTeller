# Сводка выполненных проверок

Исходная 1.0.8:
- `grok-workspace.zip` → `gitteller/evidence/apk/GitTeller-1.0.8-dev-debug.apk`: совпадение SHA-256 Grok.
- Девять `gitteller/evidence/unit-xml-1.0.8/TEST-*.xml` суммарно **78 tests, 0 failures, 0 errors** (анализ предоставленных результатов, не независимый запуск Gradle).
- `sh tests-local/run.sh`: `46 model checks`, `8 GithubAuditSmoke checks`, `PARSE OK 20` (перезапущено здесь).
- RED-зонд старых исходников: `matched known issue change count=0`, `event count=0`, `ambiguous ETag accepted=true`; ожидаемый `exit 2`.

После патча исходников 1.0.8.1:
- `sh tests-local/run.sh`: `46 model checks`, `8 GithubAuditSmoke checks`, `14 independent audit regressions`, `PARSE OK 22` (выполнено здесь).
- Атомарная замена и восстановление legacy `.bak` проверены на обычных файлах Linux; **не на Android Keystore**.
- **Не выполнялось:** Gradle Android build, установка APK, Android Keystore device tests, A52. Патч не содержится в оригинальном APK 1.0.8.
