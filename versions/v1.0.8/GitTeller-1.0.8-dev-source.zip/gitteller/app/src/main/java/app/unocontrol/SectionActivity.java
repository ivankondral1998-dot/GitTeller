package app.unocontrol;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Date;

/** Dedicated, native, full-screen project sections. No AlertDialog used for data lists. */
public final class SectionActivity extends Activity {
    private int bg, panel, ink, muted, stroke, accent;
    private LinearLayout body;
    private SharedPreferences prefs;
    private JSONObject current, previous;
    private String repo, page, seenCurrent;
    private TokenVault vault;
    private int detailEpoch;
    private int compareEpoch;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("gitteller_v1",MODE_PRIVATE);
        repo=prefs.getString("repo","octocat/Hello-World");
        seenCurrent=prefs.getString(key(repo,"current"),"");
        current=parse(seenCurrent);
        previous=parse(prefs.getString(key(repo,"previous"),""));
        vault=new TokenVault(this);
        page=getIntent().getStringExtra("page");
        if(page==null)page="index";
        if("access".equals(page))
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        paint();render();
    }
    @Override protected void onResume() {
        super.onResume();
        if(prefs==null) return;
        String selected=prefs.getString("repo",repo);
        String raw=prefs.getString(key(selected,"current"),"");
        if(selected.equals(repo) && raw.equals(seenCurrent==null?"":seenCurrent)) return;
        repo=selected;
        seenCurrent=raw;
        current=parse(raw);
        previous=parse(prefs.getString(key(repo,"previous"),""));
        paint();render();
    }
    private static String key(String repo,String suffix) {return repo.toLowerCase(java.util.Locale.ROOT)+":"+suffix;}
    private static JSONObject parse(String s) {try{return s==null||s.isEmpty()?null:new JSONObject(s);}catch(Exception e){return null;}}
    private int dp(float v) {return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void paint() {
        boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)!=Configuration.UI_MODE_NIGHT_NO;
        bg=dark?Color.rgb(12,18,25):Color.rgb(246,243,236);
        panel=dark?Color.rgb(23,33,44):Color.WHITE;
        ink=dark?Color.rgb(238,242,247):Color.rgb(28,32,38);
        muted=dark?Color.rgb(164,178,194):Color.rgb(92,99,108);
        stroke=dark?Color.rgb(47,63,80):Color.rgb(214,206,194);
        accent=dark?Color.rgb(218,174,127):Color.rgb(133,88,42);
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }
    private GradientDrawable background(int color) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(17));d.setStroke(dp(1),stroke);return d;
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int width,int height){
        return new LinearLayout.LayoutParams(width<0?width:dp(width),height<0?height:dp(height));
    }
    private TextView text(String v,int size,boolean strong,int color) {
        TextView t=new TextView(this);t.setText(v);t.setTextSize(size);t.setTextColor(color);
        t.setIncludeFontPadding(false);t.setLineSpacing(dp(2),1f);
        if(strong)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
    private void gap(LinearLayout l,int height){l.addView(new View(this),lp(1,height));}
    private TextView line(LinearLayout l,String v,int size,boolean strong,int color) {
        TextView t=text(v,size,strong,color);l.addView(t,lp(-1,-2));return t;
    }
    private LinearLayout card(){
        LinearLayout l=col();l.setPadding(dp(17),dp(18),dp(17),dp(18));
        l.setBackground(background(panel));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(13);
        body.addView(l,p);return l;
    }
    private void note(String title,String description) {
        LinearLayout card=card();line(card,title,17,true,ink);gap(card,10);line(card,description,15,false,muted);
    }
    private void action(String title,String subtitle,Runnable run) {
        LinearLayout b=card();line(b,title+"   ›",17,true,ink);gap(b,7);line(b,subtitle,14,false,muted);
        b.setContentDescription(title+". "+subtitle);b.setClickable(true);b.setFocusable(true);b.setOnClickListener(v->run.run());
    }
    private void go(String name){Intent i=new Intent(this,SectionActivity.class);i.putExtra("page",name);startActivity(i);}
    private void goItem(String name,int idx){Intent i=new Intent(this,SectionActivity.class);i.putExtra("page",name);i.putExtra("idx",idx);startActivity(i);}
    private String title() {
        switch(page){
            case "changes":return "Изменения";
            case "branches":return "Направления работы";
            case "commits":return "История изменений";
            case "tasks":return "Задачи";
            case "pulls":return "Предложения изменений";
            case "accuracy":return "Надёжность сведений";
            case "access":return "Подключение GitHub";
            case "settings":return "Настройки";
            case "why":return "Почему это не доказательство";
            case "data":return "Настройки";
            case "about":return "Настройки";
            case "branch-detail":return "Направление работы";
            case "issue-detail":return "Задача";
            case "pull-detail":return "Предложение изменений";
            case "commit-detail":return "Изменение";
            default:return "Разделы";
        }
    }
    private void render(){
        LinearLayout root=col();root.setBackgroundColor(bg);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12),dp(14),dp(12),dp(12));
        TextView back=text("‹",34,false,ink);back.setGravity(Gravity.CENTER);
        back.setContentDescription("Назад");back.setClickable(true);back.setFocusable(true);
        back.setOnClickListener(v->finish());header.addView(back,lp(48,48));
        TextView h=text(title(),18,true,ink);h.setPadding(dp(8),0,0,0);
        header.addView(h,new LinearLayout.LayoutParams(0,-2,1f));
        root.addView(header,lp(-1,-2));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        body=col();body.setPadding(dp(18),dp(8),dp(18),dp(28));scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));setContentView(root);
        switch(page) {
            case "overview":overview();break;
            case "changes":changes();break;
            case "branches":branches();break;
            case "commits":commits();break;
            case "tasks":tasks();break;
            case "pulls":pulls();break;
            case "accuracy":accuracy();break;
            case "access":access();break;
            case "settings":case "data":case "about":settings();break;
            case "why":why();break;
            case "branch-detail":branchDetail();break;
            case "commit-detail":commitDetail();break;
            case "issue-detail":case "pull-detail":taskDetail();break;
            default:index();
        }
    }
    private void index(){
        line(body,"Разделы",22,true,ink);gap(body,8);
        line(body,"Каждый раздел — отдельный экран. Кнопка «Назад» и системная кнопка Back возвращают на предыдущий.",14,false,muted);
        gap(body,14);
        action("Обзор","Что изменилось и чего нельзя утверждать",()->go("overview"));
        action("Изменения","Лента событий между проверками, с источником",()->go("changes"));
        action("Направления работы","Все ветки, включая исследовательские",()->go("branches"));
        action("История изменений","Записи выбранного направления, не весь проект сразу",()->go("commits"));
        action("Задачи","Открытые и закрытые обсуждения",()->go("tasks"));
        action("Предложения изменений","Что предлагают внести и внесено ли это",()->go("pulls"));
        action("Надёжность сведений","Что загружено полностью, а что нет",()->go("accuracy"));
        action("Подключение GitHub","Репозиторий и доступ только на чтение",()->go("access"));
        action("Настройки","Копии данных и ограничения приложения",()->go("settings"));
    }
    private void overview(){
        if(current==null){note("Нет данных","Вернитесь назад и нажмите «Обновить».");return;}
        Summary s=Summary.of(current,previous);
        note("Что изменилось", HumanReport.whatChanged(current,previous,s));
        note("Что требует внимания", HumanReport.needsAttention(current,s));
        note("Следующий шаг", HumanReport.nextStep(current,previous,s));
        note("Покрытие", HumanReport.coverageLine(current)+" "+HumanReport.syncStatus(current));
        action("Открыть направления","Посмотреть, где именно сдвинулась работа",()->go("branches"));
        action("Открыть задачи","Конкретные открытые записи",()->go("tasks"));
    }
    private void branches(){
        if(current==null){note("Нет данных","Сначала обновите проект.");return;}
        JSONArray list=current.optJSONArray("branches");
        note("Что это", "Направление — отдельная линия работы. Название только подсказывает тему. Оно не доказывает, что результат готов.");
        if(!current.optBoolean("branchesComplete",false))
            note("Покрытие", "Указатели веток проверены не полностью. Нельзя делать вывод о новых или исчезнувших направлениях.");
        else note("Покрытие", "Указатели веток проверены полностью. История каждого направления при этом изучена лишь частично.");
        if(list==null||list.length()==0){note("Список пуст","GitHub не вернул направления, либо они не загрузились.");return;}
        for(int i=0;i<list.length();i++){
            JSONObject x=list.optJSONObject(i);if(x==null)continue;final int idx=i;
            String name=x.optString("name");
            action(name.isEmpty()?"Без названия":name, HumanReport.branchAssumption(name), ()->goItem("branch-detail",idx));
        }
    }
    private void branchDetail(){
        JSONObject x=at("branches");if(x==null){note("Запись не найдена","Вернитесь к списку.");return;}
        String name=x.optString("name"),sha=x.optString("sha");
        note("Что произошло", "Открыто направление «"+name+"». "+HumanReport.branchAssumption(name));
        note("Что известно", branchDelta(name, sha));
        note("Что остаётся неизвестным", "По названию и указателю нельзя узнать, прошли ли проверки и можно ли этим пользоваться. История ниже — только последние записи, не вся работа.");
        note("Источник", sourceLine());
        technical("Направление\n"+name+"\nУказатель\n"+sha);
        String prior = priorSha(name);
        if(prior != null && !prior.equals(sha)) loadCompare(prior, sha);
        loadBranchStory(name);
    }
    private String branchDelta(String name, String sha){
        if(previous==null || previous.optBoolean("restoredFromBackup", false))
            return "Сравнивать не с чем: нет предыдущей проверки. Нельзя сказать, что направление новое или что оно стоит на месте.";
        if(!current.optBoolean("branchesComplete", false) || !previous.optBoolean("branchesComplete", false))
            return "Один из списков направлений неполный. Если указатель совпал с прошлой проверкой, это видно. Исчезновение или появление направления утверждать нельзя.";
        String prior=null;
        JSONArray old=previous.optJSONArray("branches");
        if(old!=null) for(int i=0;i<old.length();i++){
            JSONObject b=old.optJSONObject(i);
            if(b!=null && name.equals(b.optString("name"))) prior=b.optString("sha");
        }
        if(prior==null) return "В прошлой полной проверке этого направления не было. Это ещё не доказательство, что его только что создали: название могло измениться.";
        if(!prior.equals(sha)) return "Указатель этого направления изменился. Это ещё не прогресс: ниже будет сравнение GitHub, если оно доступно. Работоспособность не проверена.";
        return "Указатель с прошлой полной проверки не изменился. Это не значит, что работа закончена.";
    }
    private String priorSha(String name) {
        if(previous==null) return null;
        JSONArray old=previous.optJSONArray("branches");
        if(old==null) return null;
        for(int i=0;i<old.length();i++){
            JSONObject b=old.optJSONObject(i);
            if(b!=null && name.equals(b.optString("name"))) return b.optString("sha");
        }
        return null;
    }
    private void loadCompare(String base, String head) {
        final int epoch = ++compareEpoch;
        LinearLayout slot = card();
        TextView status = line(slot, HumanReport.NOT_ENOUGH+". Сравнение указателей ещё не получено.", 15, false, muted);
        final String selected = repo;
        new Thread(() -> {
            String text;
            try {
                String token = vault.load(selected);
                GithubClient client = new GithubClient(token == null ? "" : token);
                text = "Событие: указатели направления различаются.\nОснование: "+client.readCompare(selected, base, head)
                        +"\nНе подтверждено: тесты и готовность на Android.";
            } catch (Exception e) {
                text = HumanReport.NOT_ENOUGH+". "+GithubClient.safeMessage(e);
            }
            final String shown = text;
            runOnUiThread(() -> {
                if (isFinishing() || epoch != compareEpoch) return;
                status.setText(shown);
            });
        }, "gitteller-compare").start();
    }
    private void changes() {
        String filter = getIntent().getStringExtra("filter");
        if(filter==null) filter="all";
        line(body,"Что это",16,true,ink);gap(body,6);
        line(body,"Каждая строка — разница двух сохранённых проверок. Это не оценка готовности.",14,false,muted);
        gap(body,12);
        filterChip("Все","all",filter);
        filterChip("Новое","new",filter);
        filterChip("Проверки","checks",filter);
        filterChip("Задачи","tasks",filter);
        filterChip("Слияния","merges",filter);
        gap(body,8);
        JSONArray log = parseFeed();
        int shown=0;
        for(int i=0;i<log.length();i++){
            JSONObject event=log.optJSONObject(i);
            if(event==null || !matches(filter, event.optString("kind"))) continue;
            shown++;
            String title=event.optString("event");
            String bodyText="Основание: "+event.optString("basis")+"\nНе подтверждено: "+event.optString("unknown")
                    +"\nИсточник: "+event.optString("origin","LIVE")+", "+HumanReport.humanDate(event.optLong("at",0))+".";
            note(title.isEmpty()?"Событие":title, bodyText);
            String url=event.optString("url");
            if(url.startsWith("https://github.com/")) technical("Ссылка\n"+url+"\nИдентификатор\n"+event.optString("id"));
        }
        if(shown==0) note("Событий нет", "В этой ленте нет записей выбранного вида. Это не значит, что проект не менялся и что проблем нет.");
    }
    private void filterChip(String label, String id, String currentFilter) {
        Button b=new Button(this);
        b.setAllCaps(false);
        b.setText(label+(id.equals(currentFilter)?" · сейчас":""));
        b.setTextColor(ink);
        b.setBackground(background(id.equals(currentFilter)?accent:panel));
        b.setContentDescription("Фильтр "+label);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(6);
        b.setMinHeight(dp(48));
        b.setPadding(dp(12),dp(8),dp(12),dp(8));
        body.addView(b,p);
        b.setOnClickListener(v->{
            Intent i=new Intent(this, SectionActivity.class);
            i.putExtra("page","changes");
            i.putExtra("filter", id);
            startActivity(i);
            finish();
        });
    }
    private static boolean matches(String filter, String kind) {
        if(filter==null || "all".equals(filter)) return true;
        if("new".equals(filter)) return kind.endsWith("_new") || "branch_seen".equals(kind);
        if("checks".equals(filter)) return kind.startsWith("check");
        if("tasks".equals(filter)) return kind.startsWith("issue");
        if("merges".equals(filter)) return "pull_merged".equals(kind);
        return true;
    }
    private JSONArray parseFeed() {
        try {
            String raw=prefs.getString(key(repo,"feed"),"");
            return raw==null || raw.isEmpty() ? new JSONArray() : new JSONArray(raw);
        } catch (Exception e) { return new JSONArray(); }
    }
    private void loadBranchStory(String branch) {
        final int epoch = ++detailEpoch;
        LinearLayout slot = card();
        TextView status = line(slot, "История этого направления ещё не запрошена. Это не вся история проекта.", 15, false, muted);
        final String selected = repo;
        new Thread(() -> {
            String text;
            try {
                String token = vault.load(selected);
                GithubClient client = new GithubClient(token == null ? "" : token);
                org.json.JSONArray commits = client.readBranchCommits(selected, branch);
                if (commits.length() == 0) text = HumanReport.NOT_ENOUGH + ". История этого направления пуста или не прочитана.";
                else {
                    StringBuilder b = new StringBuilder("Последние записи только этого направления. История изучена лишь частично.\n");
                    int n = Math.min(commits.length(), 5);
                    for (int i = 0; i < n; i++) {
                        org.json.JSONObject c = commits.optJSONObject(i);
                        if (c == null) continue;
                        b.append("\n").append(i + 1).append(". ").append(HumanReport.commitSummary(c.optString("message")));
                        b.append("\n").append(HumanReport.humanDate(c.optString("date")));
                        b.append("\nЗаявление автора: ").append(c.optString("message"));
                    }
                    b.append("\n\n").append(HumanReport.NO_CHECK);
                    text = b.toString();
                }
            } catch (Exception e) {
                text = HumanReport.NOT_ENOUGH + ". " + GithubClient.safeMessage(e);
            }
            final String shown = text;
            runOnUiThread(() -> {
                if (isFinishing() || epoch != detailEpoch) return;
                status.setText(shown);
            });
        }, "gitteller-branch").start();
    }
    private void commits(){
        if(current==null){note("Нет данных","Сначала обновите проект.");return;}
        String branch=current.optString("defaultBranch","main");
        note("Что здесь", "Ниже — только последние записи основной ветки «"+branch+"». Это не последнее событие всего проекта. Другие направления открываются отдельно.");
        note("Покрытие", "История изучена лишь частично.");
        JSONArray a=current.optJSONArray("commits");
        if(a==null||a.length()==0) note("Нет записей","Список основной ветки не загрузился или пуст. Это не значит, что в других направлениях пусто.");
        else for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;final int idx=i;
            action(HumanReport.commitSummary(x.optString("message")),
                    HumanReport.humanDate(x.optString("date"))+". Заявление автора, не проверка.",
                    ()->goItem("commit-detail",idx));
        }
        gap(body,8);
        line(body,"Другие направления",16,true,ink);gap(body,8);
        action("Все направления","В том числе research и другие линии работы",()->go("branches"));
    }
    private void commitDetail(){
        JSONObject x=at("commits");if(x==null){note("Запись не найдена","Вернитесь к списку.");return;}
        String message=x.optString("message","Без описания");
        note("Что произошло", HumanReport.commitSummary(message)+".");
        note("Что заявил автор", message.isEmpty()?"Описания нет.":message);
        note("Что известно до отдельного запроса", "Запись есть в ветке «"+current.optString("defaultBranch","main")+"». Дата для человека: "+HumanReport.humanDate(x.optString("date"))+". Список файлов и проверки подгружаются ниже, если GitHub их отдаёт.");
        note("Что остаётся неизвестным", "Заголовок не доказывает, что изменение работает. Если ниже нет списка файлов или проверок — этих доказательств нет.");
        note("Источник", sourceLine());
        technical("Заголовок\n"+message+"\nКогда сохранено (как прислал GitHub)\n"+x.optString("date","нет")+"\nУказатель\n"+x.optString("sha","нет"));
        loadExtra("commit", 0, x.optString("sha"));
    }
    private void tasks(){
        if(current==null){note("Нет данных","Сначала обновите проект.");return;}
        JSONArray issues=current.optJSONArray("issues");
        if(!current.optBoolean("issuesComplete", false))
            note("Покрытие", current.optBoolean("issuesStale", false)
                    ? "Свежий список задач не получен. Ниже прошлые сведения, если они были. Нельзя сказать, сколько задач всего."
                    : "Список задач неполный или не загрузился. Нельзя сказать, что открытых задач нет.");
        else note("Покрытие", "Список задач в пределах запроса загружен. Это не все возможные проблемы программы.");
        if(issues==null || issues.length()==0){
            note("Записей в этой выборке нет", current.optBoolean("issuesComplete", false)
                    ? "GitHub вернул пустой список. Это не доказательство, что программа без дефектов."
                    : "Пустой ответ при неполной загрузке не означает ноль задач.");
            return;
        }
        for(int i=0;i<issues.length();i++){
            JSONObject x=issues.optJSONObject(i);if(x==null)continue;final int idx=i;
            String title=x.optString("title","Без названия");
            action(title, HumanReport.state(x.optString("state")), ()->goItem("issue-detail",idx));
        }
    }
    private void pulls(){
        if(current==null){note("Нет данных","Сначала обновите проект.");return;}
        JSONArray pulls=current.optJSONArray("pulls");
        if(!current.optBoolean("pullsComplete", false))
            note("Покрытие", current.optBoolean("pullsStale", false)
                    ? "Свежий список предложений не получен. Показаны прошлые сведения, если они были."
                    : "Список предложений неполный. Закрытие в видимой части не описывает весь проект.");
        else note("Покрытие", "Список предложений в пределах запроса загружен. Закрытие не означает внесение в проект.");
        if(pulls==null || pulls.length()==0){
            note("Записей в этой выборке нет", current.optBoolean("pullsComplete", false)
                    ? "GitHub вернул пустой список предложений."
                    : "Пустой ответ при неполной загрузке не означает, что предложений нет.");
            return;
        }
        for(int i=0;i<pulls.length();i++){
            JSONObject x=pulls.optJSONObject(i);if(x==null)continue;final int idx=i;
            action(x.optString("title","Без названия"), HumanReport.pullListLabel(x), ()->goItem("pull-detail",idx));
        }
    }
    private void taskDetail(){
        boolean pr="pull-detail".equals(page);
        JSONObject x=at(pr?"pulls":"issues");if(x==null){note("Запись не найдена","Вернитесь к списку.");return;}
        String title=x.optString("title","Без названия");
        note("Что произошло", (pr?"Предложение: «":"Задача: «")+title+"».");
        note("Что известно", pr ? HumanReport.pullListLabel(x) : HumanReport.state(x.optString("state")));
        note("Что остаётся неизвестным", pr
                ? "Пока нет отдельного ответа GitHub, нельзя утверждать, что предложение слито, какие файлы затронуты и прошли ли проверки."
                : "По заголовку нельзя установить, выполнена ли работа.");
        note("Источник", sourceLine());
        technical((pr?"Предложение №":"Задача №")+x.optInt("number")+"\nСостояние в GitHub: "+x.optString("state")
                +(pr?"\nОтметка внесения: "+(x.optBoolean("merged", false)?"есть":"нет"):"")
                +"\nЗаголовок\n"+title);
        loadExtra(pr ? "pull" : "issue", x.optInt("number"), null);
    }
    private void loadExtra(String kind, int number, String sha) {
        final int epoch = ++detailEpoch;
        LinearLayout slot = card();
        TextView status = line(slot, "Подробности ещё читаются из GitHub.", 15, false, muted);
        final String selected = repo;
        new Thread(() -> {
            String text;
            try {
                String token = vault.load(selected);
                GithubClient client = new GithubClient(token == null ? "" : token);
                GithubClient.Extra extra = "commit".equals(kind) ? client.readCommit(selected, sha)
                        : "pull".equals(kind) ? client.readPull(selected, number)
                        : client.readIssue(selected, number);
                text = "Подтверждения и пробелы\n\n" + extra.text;
            } catch (Exception e) {
                text = HumanReport.NOT_ENOUGH + ". " + GithubClient.safeMessage(e);
            }
            final String shown = text;
            runOnUiThread(() -> {
                if (isFinishing() || epoch != detailEpoch) return;
                status.setText(shown);
            });
        }, "gitteller-detail").start();
    }
    private JSONObject at(String field){
        if(current==null)return null;JSONArray list=current.optJSONArray(field);if(list==null)return null;
        return list.optJSONObject(getIntent().getIntExtra("idx",-1));
    }
    private String sourceLine(){
        if(current==null) return "Источник ещё не получен.";
        String kind=current.optBoolean("restoredFromBackup", false)?"Импортированный файл, не свежий запрос GitHub."
                :"PARTIAL".equals(current.optString("origin"))?"Частичный ответ GitHub, не полная проверка."
                :"CACHED".equals(current.optString("origin"))?"GitHub подтвердил прежние списки. История при этом не проверена целиком."
                :"GitHub, только чтение.";
        return kind+" Проект: "+repo+". Загрузка: "+HumanReport.humanDate(current.optLong("capturedAt",0))+".";
    }
    private void technical(String value){
        LinearLayout card=card();
        line(card,"Технические детали",13,true,muted);gap(card,8);
        line(card,value,13,false,muted);gap(card,10);
        button(card,"Скопировать технические сведения",()->{
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(clipboard!=null) clipboard.setPrimaryClip(ClipData.newPlainText("GitTeller", value));
            toast("Скопировано");
        });
    }
    private void accuracy(){
        if(current==null){note("Нет данных","Ещё не было проверки GitHub.");return;}
        note("Источник", sourceLine());
        note("Направления", (current.optBoolean("branchesStale", false)
                ? "Показан прошлый список. Свежие указатели не получены."
                : (current.optBoolean("branchesComplete", false)
                    ? "Указатели веток проверены полностью."
                    : "Указатели веток проверены не полностью.")) + sectionTime("branchesCached", "branchesFetchedAt"));
        note("История", "История изучена лишь частично. На главном снимке только последние записи основной ветки. История другого направления запрашивается, когда его открывают."
                + sectionTime("commitsCached", "commitsFetchedAt"));
        note("Задачи", (current.optBoolean("issuesStale", false) ? "Показан прошлый список задач."
                : (current.optBoolean("issuesComplete", false) ? "Список задач в пределах запроса загружен." : "Список задач неполный или недоступен. Это не ноль задач."))
                + sectionTime("issuesCached", "issuesFetchedAt"));
        note("Предложения", (current.optBoolean("pullsStale", false) ? "Показан прошлый список предложений."
                : (current.optBoolean("pullsComplete", false) ? "Список предложений в пределах запроса загружен." : "Список предложений неполный или недоступен."))
                + sectionTime("pullsCached", "pullsFetchedAt"));
        note("Проверки", "Результаты автоматических проверок запрашиваются при открытии записи. Если GitHub их не отдал, это не успех. Обычный токен может не иметь права Checks: read; тогда используются статусы коммита или GitHub Actions, если они доступны.");
        JSONArray warnings=current.optJSONArray("warnings");
        if(warnings==null||warnings.length()==0) note("Замечания загрузки","Отдельных ошибок при последней загрузке не записано. Это не значит, что проект проверен.");
        else for(int i=0;i<warnings.length();i++) note("Почему данные неполные", warnings.optString(i));
    }
    private void access(){
        note("Безопасное подключение","Для публичного репозитория токен не нужен. Для приватного нужен токен GitHub только на чтение. Он хранится в Android Keystore отдельно для каждого проекта. Токен с правом записи не нужен и здесь не запрашивается.");
        LinearLayout form=card();
        line(form,"Репозиторий GitHub",14,true,ink);gap(form,8);
        EditText repoField=new EditText(this);repoField.setSingleLine(true);repoField.setText(repo);
        repoField.setTextColor(ink);form.addView(repoField,lp(-1,-2));gap(form,15);
        String status;
        try{status=vault.hasToken(repo)?"На устройстве есть запись доступа. Она ещё не проверена расшифровкой, и секрет не показывается.":"Токен для текущего проекта не найден.";}
        catch(Exception e){status="Статус хранилища недоступен.";}
        line(form,status,14,false,muted);gap(form,12);
        line(form,"Токен. Пустое поле не удаляет сохранённый доступ.",13,false,muted);
        EditText tokenField=new EditText(this);tokenField.setSingleLine(true);tokenField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenField.setTextColor(ink);tokenField.setHint("Вставьте токен вручную");tokenField.setHintTextColor(muted);
        form.addView(tokenField,lp(-1,-2));gap(form,14);
        button(form,"Сохранить подключение",()->{
            String r=repoField.getText().toString().trim();
            if(!r.matches("[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}")||r.contains("..")){toast("Адрес должен быть вида owner/repo");return;}
            String token=tokenField.getText().toString().trim();tokenField.setText("");
            try{
                boolean wrote=false;
                if(!token.isEmpty()){vault.save(r,token);wrote=true;}
                if(!prefs.edit().putString("repo",r).commit()){toast("Не удалось выбрать проект");return;}
                setResult(RESULT_OK,new Intent().putExtra("action","changed"));
                toast(wrote?"Доступ сохранён средствами Android":"Проект выбран. Пустое поле не стирает сохранённый доступ.");
                finish();
            }catch(Exception e){toast("Не удалось сохранить токен. Проверьте хранилище Android.");}
        });
        button(form,"Удалить токен этого проекта",()->{
            String r=repoField.getText().toString().trim();
            if(!r.matches("[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}")||r.contains("..")){toast("Неверный адрес");return;}
            new AlertDialog.Builder(this).setTitle("Удалить защищённый токен?")
            .setMessage("Будет удалён только токен проекта «"+r+"». Сведения проекта сохранятся.")
            .setNegativeButton("Отмена",(d,w)->{})
            .setPositiveButton("Удалить",(d,w)->{
                try{vault.delete(r);tokenField.setText("");toast("Токен удалён");setResult(RESULT_OK,new Intent().putExtra("action","changed"));finish();}
                catch(Exception e){toast("Не удалось удалить токен.");}
            }).show();
        });
    }
    private void button(LinearLayout box,String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(ink);b.setBackground(background(panel));
        LinearLayout.LayoutParams params=lp(-1,-2);params.topMargin=dp(9);
        b.setMinHeight(dp(48));
        b.setPadding(dp(12),dp(10),dp(12),dp(10));
        box.addView(b,params);b.setOnClickListener(v->action.run());
    }
    private String sectionTime(String cacheFlag, String atKey) {
        String when = HumanReport.humanDate(current.optLong(atKey, 0));
        String cache = current.optBoolean(cacheFlag, false)
                ? " Первая страница не изменилась, показан прошлый список." : "";
        return " Время раздела: " + when + "." + cache;
    }
    private void settings(){
        note("GitTeller 1.0.8-dev", "Объясняет историю GitHub человеку без разработки. Это не коммерческий релиз и не проверка готовности программы.");
        note("Оформление", "Светлая или тёмная тема берётся из настроек телефона. Отдельный переключатель не нужен.");
        note("Безопасность", "Чтение GitHub только через HTTPS. Токены в Android Keystore, отдельно на каждый проект, не попадают в резервную копию JSON и не пишутся в журнал.");
        note("Резервные копии", "В архив попадают только сведения GitHub. Защищённый токен не экспортируется. Импортированный файл нельзя считать свежей проверкой.");
        action("Сохранить копию проекта","Создать JSON без токена",()->requestData("export"));
        action("Восстановить из JSON","Заменяет данные выбранного репозитория только после подтверждения",()->requestData("import"));
        action("Поделиться кратким отчётом","Текст для себя. Токен и тела записей не входят", this::shareReport);
        action("Почему готовность нельзя доказать коммитом","Короткое объяснение",()->go("why"));
        note("Проекты на этом телефоне","Данные и токены не смешиваются. Выбор проекта не удаляет остальные.");
        for (String stored : prefs.getAll().keySet()) {
            if (!stored.endsWith(":current")) continue;
            String name = stored.substring(0, stored.length() - ":current".length());
            if (name.isEmpty()) continue;
            action(name, name.equalsIgnoreCase(repo) ? "Сейчас открыт" : "Переключить на этот проект", () -> {
                if (!prefs.edit().putString("repo", name).commit()) { toast("Не удалось выбрать проект"); return; }
                setResult(RESULT_OK, new Intent().putExtra("action", "changed"));
                finish();
            });
        }
        note("Ограничения", "Приложение не запускает сборку и не проверяет работу на телефоне. Нехватка данных показывается как нехватка данных, а не как успех.");
    }
    private void why(){
        note("Событие", "Коммит, задача или сдвиг ветки говорят только о том, что запись появилась в GitHub.");
        note("Основание", "Основанием служит поле источника: state, merged_at, SHA или список файлов, если он загружен.");
        note("Не подтверждено", "Название ветки, префикс fix: и пометка skip ci не доказывают, что функция работает и что приёмка на телефоне пройдена.");
        note("Подробнее", "Технические поля и ссылка на github.com этого репозитория лежат внизу карточки. Их отсутствие означает «не проверено», а не «всё хорошо».");
    }
    private void shareReport(){
        Summary s=Summary.of(current, previous);
        String text="GitTeller\n"+repo+"\n"+HumanReport.syncStatus(current)+"\n\nЧто изменилось:\n"
                +HumanReport.whatChanged(current, previous, s)+"\n\nЧто требует внимания:\n"
                +HumanReport.needsAttention(current, s)+"\n\n"+HumanReport.coverageLine(current)
                +"\n\nЭто не проверка работоспособности и не отчёт о готовности.";
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, "Краткий отчёт"));
    }
    private void requestData(String actionName){setResult(RESULT_OK,new Intent().putExtra("action",actionName));finish();}
    private void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();}
}
