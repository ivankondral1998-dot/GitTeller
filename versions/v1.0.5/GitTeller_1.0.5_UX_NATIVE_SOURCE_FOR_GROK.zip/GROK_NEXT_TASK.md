# GROK — TASK: FINISH REAL USER-FACING ANDROID UX

Owner's observed failure: the app loads GitHub, yet displays a gray AlertDialog filled with raw branch names, SHA, English commits and labels. That is not the finished product. The app must help a non-developer understand what can and cannot be established from evidence.

## BASE & SCOPE

- Base source **1.0.4**, with independent test-safety patch. Unmodified checkpoint in `checkpoint/`.
- This **1.0.5-ux-source** contains an initial native full-screen navigation patch. Check it independently and finish it; do not blindly trust this patch.
- GitTeller only. UNO GitHub repo, main, actions, UNO source: **DO NOT TOUCH**.
- No paid APIs, WebView, backend, or new dependencies by default. Read-only GitHub access.

## MANDATORY UX ACCEPTANCE

1. On A52 Android 14, main screen displays at most **one primary status** and **one simple next-action callout** in the first viewport. The user does not need to understand SHA/Git/PR to see what happened.
2. Every section opens a **full native Android screen**, not a scrolling AlertDialog. Top back arrow + Android system Back must return to previous screen without losing state.
3. `⋮` stays short. More detailed sections have discoverable navigation. No 18-branch wall in a popup.
4. Each branch page shows a **cautious topic hint**, and hides the raw branch name and SHA in its technical details, instead of dumping SHA in lists.
5. Explain up front that **the commits list refers only to `defaultBranch`**, NOT all work in the repository. Never display a commit on `main` as "the most recent project change" when research branches may have newer commits.
6. Show issues and PRs separately. `closed` alone does not prove `merged`. `open` does not prove unimplemented; `merged` does not prove tested.
7. A story about "what was done" needs independently read GitHub descriptions/changed files/test evidence. If these are not fetched, clearly say **"Недостаточно данных"**, not a confident conclusion.
8. Human summaries **cannot assume project-specific file naming**, must preserve source and confidence. Translation and rules-based labels must be reversible to originals. Unrecognized details must be treated as unknown.
9. Access settings must use existing `TokenVault`: persist per repo, show no plaintext, remove only selected repo's token, never export it. Switching repo during ongoing sync cancels stale request.
10. No authentication token in Android logs, backup, screenshots, bug reports or CI output. Never ask user for token in a chat.
11. On actual device test at least the following: first sync, second sync with unchanged HEAD, branch list, commit page, issue/PR detail, switch project, app restart, token persisted, invalid token 401, offline/error retains old snapshot, system Back, small-screen portrait, light/dark themes.
12. Do not claim full semantic analysis until GitHub diff/PR contents and CI test metadata are actually loaded and linked. Without independent tests, show **"Проверка работоспособности отсутствует"**.

## RECOMMENDED NEXT TECHNICAL WORK

- Proper detail GET fetch on demand for issues (description, labels), PR (merged_at, changed filenames and check-runs if available), commits (changed filenames/status), with pagination, 403/429 and offline handling.
- Persist a bounded per-repo history of snapshots; current export fixture has `previous=null`, therefore it cannot independently demonstrate multiple updates.
- More natural descriptions of real changed files without hallucinating behavior. Run representative case-based tests, e.g. docs-only, failing checks, changed branch without completed tests, ambiguous PR closed/merged, missing data.
- Review for accessibility and performance on a 4GB device.

## DELIVERABLES

- Source ZIP, native APK, commit/diff manifest and SHA-256.
- `gradle --no-daemon :app:testDebugUnitTest`, `:app:assembleDebug` and all accessible instrumentation results with raw logs/exit codes.
- Real screenshot of all full-screen pages from A52 or an emulator that actually renders, not launcher splash/ANR dialogs.
- Explicit per-criterion PASS/FAIL/NOT_RUN backed by evidence, with device verification separate from compilation.

**Never declare commercial readiness from a successful build or just a changed navigation layout.**
