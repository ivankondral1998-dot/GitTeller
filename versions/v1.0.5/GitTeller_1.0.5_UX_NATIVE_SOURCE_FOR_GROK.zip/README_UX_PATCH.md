# GitTeller 1.0.5-ux-source — continuation of 1.0.4

**STATUS: SOURCE PATCH ONLY, NOT APK, NOT ANDROID VERIFIED.**

Owner report from Samsung Galaxy A52: GitTeller 1.0.4 launched, GitHub synchronization worked again after app restart, and data appears in UI. Screenshots provided 14 November 2026. This is evidence of a user-operated scenario, NOT independent security verification, QA on all screens, or commercial readiness.

Preserved checkpoint: `checkpoint/1.0.4_INDEPENDENT_AUDIT_UNCHANGED.zip` (not modified). Current patch modifies only the GitTeller app. The **UNO GitHub repository is untouched**; main, GitHub Actions, and all production code in UNO remain unchanged.

## Problem

The previous experience showed raw branch names, 10-character SHA substrings, English commit titles and long `AlertDialog` lists. An ordinary user cannot establish what was done, what remains unverified, or why the project appears unchanged. Worse: commits fetched from `defaultBranch` were presented as if they represented the entire project's latest work, although other branches may have newer commits.

## Implemented native UX changes

- Replaced the nine-entry overflow menu with four entries: project sections, access, backups, about.
- Added **SectionActivity** as a real fullscreen native Android screen, registered as `exported=false`. It uses the system Back stack and a visible Back control.
- Added page routes for overview, branches, branch details, commits, commit details, tasks/issues/PR, task details, data quality, access, backups, and about.
- New main heading `Что происходит с проектом`, replacing the default technical SHA terminology with conservative everyday phrasing.
- Commit panel now explicitly says it represents **only the default branch**. Its headline is a broad classification of the title; original English and SHA appear on an optional details page.
- Branch cards show categories and explicitly marked *topic guesses by branch name*, with raw branch name/SHA on individual detail pages.
- Tasks and PRs use Russian state descriptions. **Closed ≠ verified**; since `merged_at` is not in the snapshot, no claim of merge is made.
- Token access moved to a full-size screen, without displaying the secret. It uses the unchanged `TokenVault` API with per-repository Keystore encryption. Key deletion is confirmed per repository; an empty input does not replace a token.
- Legacy data import/export still uses the previously established SAF flows; protected tokens remain excluded. A menu route provides a full-screen explanation before initiating the platform file picker.

## What this patch cannot do

The snapshot contains only branch names/SHA, up to 12 recent commits **on the default branch**, issue and PR numbers/titles/states. It does not contain issue descriptions, PR diffs, checks, merge metadata, documentation contents, CI evidence, developer intent, or actual Android verification. Descriptive guesses **must not** be upgraded into `PASS`.

A longer-term version needs safe, rate-limited GET of detail endpoints after a user opens each item, with explicit source/date and failure modes, not dozens of requests upon opening the app.

## Tests performed here

- `sh tests-local/run.sh`: **PASS: 26 model checks; PARSE OK: 15 Java compilation units.** Tests use local org.json doubles; Java parse is syntax only.
- Static navigation contract check (registered non-exported Activity, route names, token vault unchanged): PASS.
- Uploaded JSON inspected: **18 branches, 12 default-branch commits, 2 issues, 4 PRs, `previous=null`** in that exported file. No apparent PAT prefix found in that JSON; this is not a forensic secret scan.

**NOT RUN**: Android Gradle build, emulator UI, install on Galaxy A52, private GitHub network test, UI accessibility, full Android instrumentation. No APK produced.

## Owner/Grok handoff

See `GROK_NEXT_TASK.md`; package contains six owner screenshots and a JSON example. **These attachments include private repository metadata**, for internal audit only. DO NOT commit them to public source control or ship in APK.
